# Project Title & Description

photo-albums

Web app computer project made at HE2B-ESI school for security course.

## Coaches

- [@Romain Absil](https://www.he2b.be/) | rabsil@he2b.be
- [@Nicolas Richard](https://www.he2b.be/) | nrichard@he2b.be

## Developers

- [@youssefrajoul](https://www.github.com/youssefrajoul)
- [@ilias Mohamed Chairi Kahloun](https://github.com/heisenbergili)

## 🚀 About Me

I'm a student at HE2B-ESI software development school at brussels
