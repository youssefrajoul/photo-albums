package com.youssefrajoul.photoalbums;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PhotoAlbumsApplication {

	public static void main(String[] args) {
		SpringApplication.run(PhotoAlbumsApplication.class, args);
	}

}
