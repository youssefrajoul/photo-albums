package com.youssefrajoul.photoalbums;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhotoAlbumsApplicationTests {

	@Test
	void contextLoads() {
	}

}
